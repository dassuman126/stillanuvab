<?php

return [
    'category_created' => 'Category Created !',
    'category_updated' => 'Category Updated !',
    'category_deleted' => 'Category Deleted !',
    'post_created' => 'Post Created !',
    'post_updated' => 'Post Updated !',
    'post_deleted' => 'Post Deleted !',
    'album_created' => 'Album Created !',
    'album_updated' => 'Album Updated !',
    'album_deleted' => 'Album Deleted !',
    'page_created' => 'Page Created !',
    'page_updated' => 'Page Updated !',
    'page_deleted' => 'Page Deleted !',
    'data_updated' => 'Data Deleted !',
    'tag_created' => 'Tag Created !',
    'tag_updated' => 'Tag Updated !',
    'tag_deleted' => 'Tag Deleted !',
    'user_deleted' => 'User Deleted !',
    'role_updated' => 'Role to user Updated !',
];
