<div>
    <!-- The whole future lies in uncertainty: live immediately. - Seneca -->
</div>