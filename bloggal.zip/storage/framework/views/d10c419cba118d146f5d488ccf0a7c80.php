<?php if (isset($component)) { $__componentOriginal8995a876bdf490faf24c1d189b006974 = $component; } ?>
<?php $component = App\View\Components\BlogLayout::resolve(['title' => ''.e($category_name).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('blog-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\BlogLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Posts Section -->
    <section class="w-full md:w-2/3 flex flex-col items-center px-3">


        <!-- Article -->
        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <article class="flex flex-col shadow my-4">
                <a href="<?php echo e(route('post.show', $post->slug)); ?>" class="hover:opacity-75">
                        <img src="<?php echo e(asset("storage/$post->image")); ?>" width="1000" height="500">
                </a>
                <div class="bg-white flex flex-col justify-start p-6">
                    <a href="<?php echo e(route('category.show', $post->category->slug)); ?> "
                        class="text-blue-700 text-sm font-bold uppercase pb-4"><?php echo e($post->category->name); ?></a>
                    <a href="<?php echo e(route('post.show', $post->slug)); ?>"
                        class="text-3xl font-bold hover:text-gray-700 pb-4"><?php echo e($post->title); ?></a>
                    <p href="#" class="text-sm pb-1">
                        By <a href="#" class="font-semibold hover:text-gray-800"><?php echo e($post->user->name); ?></a>,
                        Published on <?php echo e($post->created_at); ?>

                    </p>
                    <p class="pb-3"><?php echo substr($post->content, 0, 100); ?> ...</p>
                    
                    <a href="<?php echo e(route('post.show', $post->slug)); ?>"
                        class="mt-px uppercase text-gray-800 font-bold hover:text-black">Continue Reading <i
                            class="fas fa-arrow-right"></i></a>
                </div>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>
                No Posts has been added
            </p>
        <?php endif; ?>

        <!-- Pagination -->
        <div class="flex items-center py-8">
            <?php echo e($posts->links()); ?>


            
        </div>

    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8995a876bdf490faf24c1d189b006974)): ?>
<?php $component = $__componentOriginal8995a876bdf490faf24c1d189b006974; ?>
<?php unset($__componentOriginal8995a876bdf490faf24c1d189b006974); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\bloggal\resources\views/front/category.blade.php ENDPATH**/ ?>